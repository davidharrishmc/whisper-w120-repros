OUTPUT_ARCH("riscv")
ENTRY(rvtest_entry_point)
SECTIONS
{
  . = 0x80000000;
  .text.init : { *(.text.init) }
  .text : { *(.text) *(.text.*) }
  . = ALIGN(0x1000);
  .tohost : { *(.tohost) }
  . = ALIGN(0x1000);
  .data : { *(.data) *(.data.*) *(.rodata) *(.rodata.*) *(.sdata) *(.sdata.*) }
  .bss : { *(.bss) *(.bss.*) *(.sbss) *(COMMON) }
  _end = .;
}
